<div class="item-ckw">
    <div class="shareable-links">
        <div>
            <span onclick="handleShare()">
                <i class="fa fa-share-alt"></i> share
            </span>
            <a href="#">
                <i class="fa fa-at"></i>
            </a>
            <a href="#">
                <i class="fab fa-linkedin"></i>
            </a>
            <a href="#">

                <i class="fab fa-twitter"></i>
            </a>
            <a href="#">

                <i class="fab fa-whatsapp"></i>
            </a>
            <a href="#">
                <i class="fab fa-telegram"></i>

            </a>
            <a href="#">
                <i class="fab fa-facebook"></i>
            </a>
        </div>
    </div>
</div>