<div class="mid-xzewx">
    <div class="mid-particles page-size"></div>
    <div class="page-size mid-in-xz">
        <span class="title">WireBlue</span>
        <span class="sub-title">Find World most firmwares servers</span>
        <div id="search-wrap">
            <input type="text" id="search-input" placeholder="Enter model code or device name" />
            <div class="srch-results">
            </div>
        </div>
        <?php echo RealMan(); ?>
    </div>
</div>