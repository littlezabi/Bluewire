<div class="home-right" id="home-right-modals">
    <div>
        <div class="loading delay2 h40" style="margin-top: 5px"></div>
        <div class=" loading delay5 h20 w8" style="margin-top: 5px"></div>
        <div class=" loading delay3 h20 w4" style="margin-top: 5px"></div>
    </div>
    <div>
        <div class=" loading delay3 h20" style="margin-top: 5px"></div>
        <div class=" loading delay4 h30" style="margin-top: 10px"></div>
        <div class=" loading delay3 h20 w6" style="margin-top: 30px"></div>
        <div class="loading delay2 h50" style="margin-top: 5px"></div>
    </div>
</div>