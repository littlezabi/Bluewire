<script src="/static/js/axios.js"></script>
<script src="/static/js/main.js"></script>
<script type="module" src="/static/js/render-data.js">
</script>
<script type="module">
    import Render from '/static/js/render-data.js';
    new Render(data, modals, latest_devices)
</script>