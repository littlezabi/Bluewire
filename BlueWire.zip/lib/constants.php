<?php

define('ROOT', 'http://127.0.0.1/');
define('FRONTEND', PATH . '/screens/frontend/');
define('BACKEND', PATH . '/screens/backend/');
define('COMPONENTS', PATH . '/screens/components/');
// define('URL_QUERY', PATH . '');
