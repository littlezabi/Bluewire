<?php
define('ROOT', 'http://127.0.0.1/');
define('FRONTEND', PATH . '/admin/view/');
define('BACKEND', PATH . '/admin/backend/');
define('COMPONENTS', PATH . '/admin/components/');
define('MODULES', PATH . '/admin/modules/');
// define('URL_QUERY', PATH . '');
