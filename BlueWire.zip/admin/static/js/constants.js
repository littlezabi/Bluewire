var ROOT_PATH = "/admin/";
var BACKEND_MODULES = "/admin/modules/";
var ROOT_URL = "http://localhost/";
