<?php
$title = "BlueWire Admin";
require_once BACKEND . 'head.php';
require_once BACKEND . 'header.php';
