<?php ob_start("ob_gzhandler"); ?>
<?php
require_once('../modules/database.php');
$d = "SELECT COUNT(*) as total_devices FROM devices WHERE 1";
$q = $con->query($d);
$total_dev = [];
if ($q->num_rows > 0) {
    $total_dev = $q->fetch_assoc();
    $total_dev = $total_dev['total_devices'];
}
?>

<div class="dashboard">
    <section>
        <span class="text">
            <?php echo $total_dev; ?>
        </span>
        <span>
            Devices
            <i class="fa fa-mobile"></i>
        </span>
    </section>
</div>