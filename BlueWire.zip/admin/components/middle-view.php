<div class="mid-xzewx">
    <div class="mid-particles"></div>
</div>